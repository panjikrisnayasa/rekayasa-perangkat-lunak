<?php
  header('Access-Control-Allow-Origin: *');
  define('HOST','localhost');
  define('USER','playonid_panji'); //sesuaikan nama user
  define('PASS','successisaniceberg'); //sesuaikan nama password
  define('DB','playonid_ppk_panji'); //sesuaikan nama database
  $conn = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');
  date_default_timezone_set("Asia/Jakarta");
  // if ($conn == true) {
  //   echo "Koneksi sukses";
  // } else {
  //   echo "Koneksi gagal";
  // }
?>
