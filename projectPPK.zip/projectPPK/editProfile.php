<?php
    REQUIRE_ONCE('koneksi.php');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: POST');
    header('Content-Type:application/json;charset=utf-8');
    if (isset($_GET['email'])) {
        $QUERY = MYSQLI_QUERY($conn,
        'SELECT * FROM mahasiswa WHERE emailUB = "'.$_GET['email'].'";'
        );
        $rows = array();
        while ($ROW = MYSQLI_FETCH_ASSOC($QUERY)) {
        $rows[] = $ROW;
        }
        header('Content-Type:application/json;charset=utf-8');
        echo json_encode($rows);
        MYSQLI_CLOSE($conn);    
    }
?>