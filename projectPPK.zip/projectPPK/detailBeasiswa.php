<?php
    REQUIRE_ONCE('koneksi.php');
    if (isset($_GET['idPost'])) {
        $QUERY = MYSQLI_QUERY($conn,
        'SELECT * FROM beasiswa WHERE idPost = "'.$_GET['idPost'].'";'
        );
        $rows = array();
        while ($ROW = MYSQLI_FETCH_ASSOC($QUERY)) {
        $rows[] = $ROW;
        }
        header('Content-Type:application/json;charset=utf-8');
        echo json_encode($rows);
        MYSQLI_CLOSE($conn);
    }
?>
