var Application = {
    initApplication: function () {
        $(window).load('pageinit', '#page-beasiswa', function () {
            Application.initShowAllBeasiswa();
        })
        $(window).load('pageinit', '#page-beasiswa-loggedin', function () {
            Application.initShowAllBeasiswaLoggedIn();
        })
        $(document).on('click', '#detail-beasiswa', function () {
            var idbeasiswa = $(this).data('idbeasiswa');
            Application.initBeasiswaDetail(idbeasiswa);
        })
        $(document).on('click', '#detail-beasiswa-loggedin', function () {
            var idbeasiswa = $(this).data('idbeasiswa');
            Application.initBeasiswaDetailLoggedIn(idbeasiswa);
        })
        $(document).on('click', '#btn-login', function () {
            var emailUB = $('#emailUB').val();
            var password = $('#password').val();
            Application.initLoginProcess(emailUB, password);
        })
        $(document).on('click', '#btn-sign-up', function () {
            var emailUB = $('#regisEmail').val();
            var nama = $('#regisNama').val();
            var password = $('#regisPass').val();
            Application.initSignUpProcess(emailUB, nama, password);
        })
        $(document).on('click', '#btn-daftar', function () {
            alert("Terima kasih telah mendaftar, persyaratan lebih detail dan link pengumpulan berkas akan kami kirimkan ke email Anda!");
        })
        $(document).on('click', '#btn-logout', function () {
            window.location.replace("index.html#page-beasiswa");
        })
        $(document).on('click', '#btn-edit-profile', function () {
            var obj = JSON.parse(sessionStorage.user);
            window.location.replace("index.html#page-edit-profile");
            Application.initEditProfile(obj);
        })
        $(document).on('click', '#btn-delete-account', function () {
            var obj = JSON.parse(sessionStorage.user);
            Application.initDeleteAccountProcess(obj);
        })
        $(document).on('click', '#btn-edit-profile-process', function () {
            var obj = JSON.parse(sessionStorage.user);
            var nama = $('#nama').val();
            var password = $('#pass').val();
            Application.initEditProfileProcess(obj, nama, password);
        })
    },

    initShowAllBeasiswa: function () {
        $.ajax({
            url: 'http://playon-id.com/ppk_panji/web_service.php',
            type: 'get',
            success: function (dataObject) {
                var appendData = '';
                for (var i = 0; i < dataObject.length; i++) {
                    var appendData = appendData + '<li class="ui-li-has-thumb ui-first-child"><a href="#page-beasiswa-detail" target="_self" id="detail-beasiswa" data-idbeasiswa="' +
                        dataObject[i].idPost + '" class="ui-btn ui-btn-icon-right ui-icon-carat-r"><img style="margin:8px;" src="css/' +
                        dataObject[i].poster + '"><h2>' +
                        dataObject[i].judul + '</h2></a></li>';
                }
                $('#beasiswa-list').append(appendData);
            }
        })
    },

    initBeasiswaDetail: function (idbeasiswa) {
        $.ajax({
            url: 'http://playon-id.com/ppk_panji/detailBeasiswa.php?idPost='+idbeasiswa,
            type: 'get',
            success: function (dataObject) {
                var appendData = '';
                $('#beasiswa-detail').empty();
                appendData = '<img style="width:100%" src="css/'+dataObject[0].poster+'">'+
                '<h1><center>'+dataObject[0].judul+'</center></h1>'+
                '<div style="text-align:justify; text-indent:2em;"><h5>'+dataObject[0].isi+'</h5></div>';
                $('#beasiswa-detail').append(appendData);
            }
        })
    },

    initShowAllBeasiswaLoggedIn: function () {
        $.ajax({
            url: 'http://playon-id.com/ppk_panji/web_service.php',
            type: 'get',
            success: function (dataObject) {
                var appendData = '';
                for (var i = 0; i < dataObject.length; i++) {
                    var appendData = appendData + '<li class="ui-li-has-thumb ui-first-child"><a href="#page-beasiswa-detail-loggedin" target="_self" id="detail-beasiswa-loggedin" data-idbeasiswa="' +
                        dataObject[i].idPost + '" class="ui-btn ui-btn-icon-right ui-icon-carat-r"><img style="margin:8px;" src="css/' +
                        dataObject[i].poster + '"><h2>' +
                        dataObject[i].judul + '</h2></a></li>';
                }
                $('#beasiswa-list-loggedin').append(appendData);
            }
        })
    },

    initBeasiswaDetailLoggedIn: function (idbeasiswa) {
        $.ajax({
            url: 'http://playon-id.com/ppk_panji/detailBeasiswa.php?idPost='+idbeasiswa,
            type: 'get',
            success: function (dataObject) {
                var appendData = '';
                $('#beasiswa-detail-loggedin').empty();
                appendData = '<img style="width:100%" src="css/'+dataObject[0].poster+'">'+
                '<h1><center>'+dataObject[0].judul+'</center></h1>'+
                '<div style="text-align:justify; text-indent:2em;"><h5>'+dataObject[0].isi+'</h5></div>';
                $('#beasiswa-detail-loggedin').append(appendData);
            }
        })
    },

    initLoginProcess: function (emailUB, password) {
        var emailUB = emailUB;
        var password = password;
        var nama = '';
        var login = false;
        $.ajax({
            type: "post",
            url: "http://playon-id.com/ppk_panji/login.php",
            data:{ emailUB:emailUB, password:password },
            success:function(dataObject)
            {
                if (emailUB == '' || password == '') {
                    alert("NIM atau password masih kosong!");
                } else {
                    for (var i in dataObject) {
                        if (emailUB == dataObject[i].emailUB && password == dataObject[i].password) {
                            nama = dataObject[i].nama;
                            login = true;
                            sessionStorage.setItem('user', JSON.stringify(dataObject[i].emailUB));
                        }
                    }
                    if (login) {
                        alert("Selamat datang "+nama+"!");
                        window.location.replace("index.html#page-beasiswa-loggedin");
                    } else {
                        alert("NIM atau password salah!");
                    }
                }
            }
        })
    },

    initSignUpProcess: function (emailUB, nama, password) {
        var emailUB = emailUB;
        var nama = nama;
        var password = password;
        $.ajax({
        type:"post",
        url: "http://playon-id.com/ppk_panji/signup.php",
        data:{ emailUB:emailUB, nama:nama, password:password },
            success:function(dataObject)
            {
                alert("Sign up berhasil!");
                window.location.replace("index.html");
            }
        })
    },

    initDeleteAccountProcess: function (obj) {
        var obj = obj;
        $.ajax({
            type:"post",
            url: "http://playon-id.com/ppk_panji/deleteAccount.php",
            data:{ obj:obj },
            success:function(dataObject)
            {
                window.location.replace("index.html");
                alert("Akun Anda telah terhapus!");
            }
        })
    },

    initEditProfile: function (obj) {
        var obj = obj;
        $.ajax({
            url: 'http://playon-id.com/ppk_panji/editProfile.php?email='+obj,
            type: 'get',
            data:{ obj:obj },
            success: function (dataObject) {
                var appendData = '';
                $('#edit-profile-box').empty();
                appendData = 'Nama:<br><div class="ui-input-text ui-body-inherit ui-corner-all ui-shadow-inset"><input type="text" id="nama" value="'+dataObject[0].nama+'"></div>'+
				'Password:<br><div class="ui-input-text ui-body-inherit ui-corner-all ui-shadow-inset"><input type="password" id="pass"></div>' +
				'<div class="ui-btn ui-input-btn ui-corner-all">Save<input type="button" id="btn-edit-profile-process" value="Save"></div>';
                $('#edit-profile-box').append(appendData);
            }
        })
    },

    initEditProfileProcess: function (obj, nama, password) {
        var obj = obj;
        var nama = nama;
        var password = password;
        $.ajax({
            type:"post",
            url: "http://playon-id.com/ppk_panji/editProfileProcess.php",
            data:{ obj:obj, nama:nama, password:password },
            success:function(dataObject)
            {
               alert("Nama dan password Anda berhasil diubah!");
               window.location.replace("index.html#page-beasiswa-loggedin");
               location.reload();
            }
        })
    },
};