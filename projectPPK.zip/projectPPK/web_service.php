<?php
  header('Access-Control-Allow-Origin: *');
  REQUIRE_ONCE('koneksi.php');
  $QUERY = MYSQLI_QUERY($conn,
  "SELECT * FROM beasiswa"
  );
  $rows = array();
  while ($ROW = MYSQLI_FETCH_ASSOC($QUERY)){
      $rows[] = $ROW;
  }
  header('Content-Type:application/json;charset=utf-8');
  echo json_encode($rows);
  MYSQLI_CLOSE($conn);
?>
