<?php
  REQUIRE_ONCE('koneksi.php');
    $emailUB = $_POST['emailUB'];
    $nama = $_POST['nama'];
    $password = $_POST['password'];
    $QUERY = MYSQLI_QUERY($conn,
    "INSERT INTO `mahasiswa` (`emailUB`, `nama`, `password`) VALUES ('$emailUB', '$nama', '$password');"
    );
    MYSQLI_CLOSE($conn);
?>
