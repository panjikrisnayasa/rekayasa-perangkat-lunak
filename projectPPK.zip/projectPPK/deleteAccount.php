<?php
    REQUIRE_ONCE('koneksi.php');
    $obj = $_POST['obj'];
    $query = mysqli_query($conn, "DELETE FROM mahasiswa WHERE emailUB = '$obj';");
    mysqli_close($conn);
?>