<?php
    REQUIRE_ONCE('koneksi.php');
    $obj = $_POST['obj'];
    $nama = $_POST['nama'];
    $password = $_POST['password'];
    $query = mysqli_query($conn, "UPDATE `mahasiswa` SET `nama`='$nama', `password`='$password' WHERE `emailUB`='$obj';");
    mysqli_close($conn);
?>